const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const db = require('../db/connection')

// 🧾 REGISTRO
const register = async (req, res) => {
  const { usuario, contraseña } = req.body

  try {
    const hash = await bcrypt.hash(contraseña, 10)

    const result = await db.query(
      'INSERT INTO usuarios (usuario, contraseña) VALUES ($1, $2) RETURNING *',
      [usuario, hash]
    )

    res.json({ mensaje: 'Usuario creado' })

  } catch (error) {
    console.error(error)
    res.status(500).json({ mensaje: 'Error al registrar' })
  }
}

// 🔐 LOGIN
const login = async (req, res) => {
  const { usuario, contraseña } = req.body

  try {
    const result = await db.query(
      'SELECT * FROM usuarios WHERE usuario = $1',
      [usuario]
    )

    if (result.rows.length === 0) {
      return res.status(400).json({ mensaje: 'Usuario no existe' })
    }

    const user = result.rows[0]

    const valido = await bcrypt.compare(contraseña, user.contraseña)

    if (!valido) {
      return res.status(400).json({ mensaje: 'Contraseña incorrecta' })
    }

    const token = jwt.sign(
      { id: user.id, usuario: user.usuario },
      'secreto',
      { expiresIn: '1h' }
    )

    res.json({ mensaje: 'Login exitoso', token })

  } catch (error) {
    console.error(error)
    res.status(500).json({ mensaje: 'Error en login' })
  }
}

module.exports = { register, login }