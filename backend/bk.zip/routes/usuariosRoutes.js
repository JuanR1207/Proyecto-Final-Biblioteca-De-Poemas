const express = require('express')
const router = express.Router()
const pool = require('../db/connection')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')

// Registrar usuario
router.post('/register', async (req, res) => {
  const { usuario, contraseña } = req.body
  if (!usuario || !contraseña) return res.status(400).json({ mensaje: 'Datos incompletos' })

  try {
    const existente = await pool.query('SELECT * FROM usuarios WHERE usuario=$1', [usuario])
    if (existente.rows.length > 0) {
      return res.status(400).json({ mensaje: 'El usuario ya existe' })
    }

    const hash = await bcrypt.hash(contraseña, 10)

    await pool.query(
      'INSERT INTO usuarios (usuario, contrasena, rol, creado_en) VALUES ($1, $2, $3, NOW())',
      [usuario, hash, 'usuario']
    )

    res.status(201).json({ mensaje: 'Usuario creado correctamente' })
  } catch (error) {
    console.error('Error al crear usuario:', error)
    res.status(500).json({ mensaje: 'Error del servidor' })
  }
})

// Login
router.post('/login', async (req, res) => {
  const { usuario, contraseña } = req.body
  if (!usuario || !contraseña) return res.status(400).json({ mensaje: 'Datos incompletos' })

  try {
    const result = await pool.query('SELECT * FROM usuarios WHERE usuario=$1', [usuario])
    if (result.rows.length === 0) return res.status(400).json({ mensaje: 'Usuario no encontrado' })

    const user = result.rows[0]
    const match = await bcrypt.compare(contraseña, user.contrasena)
    if (!match) return res.status(400).json({ mensaje: 'Contraseña incorrecta' })

    const token = jwt.sign(
      { id: user.id, usuario: user.usuario, rol: user.rol },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    )

    res.json({ id: user.id, usuario: user.usuario, rol: user.rol, token })
  } catch (error) {
    console.error('Error login:', error)
    res.status(500).json({ mensaje: 'Error del servidor' })
  }
})

module.exports = router