const poemaModel = require('../models/poemaModel')

const getAllPoemas = () => poemaModel.getAll()
// ✅ Expone el filtro por usuario
const getPoemasDeUsuario = (usuario_id) => poemaModel.getAllByUsuario(usuario_id)
const getPoemaById = (id) => poemaModel.getById(id)
const createPoema = (t, c, a, u) => poemaModel.create(t, c, a, u)
const updatePoema = (id, t, c, a) => poemaModel.update(id, t, c, a)
const deletePoema = (id) => poemaModel.remove(id)

module.exports = {
  getAllPoemas,
  getPoemasDeUsuario,
  getPoemaById,
  createPoema,
  updatePoema,
  deletePoema
}