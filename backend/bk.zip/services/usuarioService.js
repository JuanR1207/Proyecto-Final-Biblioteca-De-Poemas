const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const userModel = require('../models/usuarioModel')

const SECRET = process.env.JWT_SECRET

const registerUser = async (usuario, contrasena) => {
  const hashed = await bcrypt.hash(contrasena, 10)
  return await userModel.createUser(usuario, hashed)
}

const loginUser = async (usuario, contrasena) => {
  const user = await userModel.getUserByUsername(usuario)

  if (!user) throw new Error('Usuario no existe')

  const valid = await bcrypt.compare(contrasena, user.contrasena)

  if (!valid) throw new Error('Contraseña incorrecta')

  const token = jwt.sign(
    { id: user.id, rol: user.rol },
    SECRET,
    { expiresIn: '2h' }
  )

  return { token, user }
}

module.exports = { registerUser, loginUser }