import { createContext, useContext, useState, useEffect } from "react";

export const PoemasContext = createContext();

export const PoemasProvider = ({ children }) => {

  const [poemas, setPoemas] = useState([])

  // 📥 obtener poemas
  const obtenerPoemas = async () => {
    try {
      const res = await fetch('http://localhost:3000/api/poemas')
      const data = await res.json()
      setPoemas(data)
    } catch (error) {
      console.error(error)
    }
  }

  // ✍️ crear poema
  const crearPoema = async (poema) => {
    try {
      const res = await fetch('http://localhost:3000/api/poemas', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(poema)
      })

      const data = await res.json()
      console.log(data)

      obtenerPoemas()
    } catch (error) {
      console.error(error)
    }
  }

  useEffect(() => {
    obtenerPoemas()
  }, [])

  return (
    <PoemasContext.Provider value={{ poemas, crearPoema }}>
      {children}
    </PoemasContext.Provider>
  )
}

// 🔥 ESTA LÍNEA ES LA QUE TE FALTA
export const usePoemas = () => useContext(PoemasContext)